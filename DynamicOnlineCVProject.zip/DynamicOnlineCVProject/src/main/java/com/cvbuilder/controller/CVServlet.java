package com.cvbuilder.controller;

import com.cvbuilder.model.CVBean;
import java.io.IOException;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class CVServlet extends HttpServlet {

    // GET request: show the sample CV when action=sample
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String action = request.getParameter("action");

        if ("sample".equals(action)) {
            // Create a bean with dummy data using the setters
            CVBean cvBean = new CVBean();
            cvBean.setFullName("Nurul Aina Hamzah");
            cvBean.setProfessionalTitle("Junior Web Developer");
            cvBean.setEmail("nurulaina@example.com");
            cvBean.setPhone("+60 11-2345 6789");
            cvBean.setProfileUrl("www.linkedin.com/in/nurulaina");
            cvBean.setProfileSummary("Final year Computer Science student who enjoys building web "
                    + "applications with Java EE. Able to work in a team, learn new tools quickly "
                    + "and complete tasks on time. Looking for an opportunity to grow as a web developer.");
            cvBean.setDegree("Bachelor of Computer Science (Hons.)");
            cvBean.setMajor("Computer Science");
            cvBean.setInstitution("Universiti Teknologi MARA");
            cvBean.setGraduationYear("2027");
            cvBean.setJobTitle("Web Development Intern");
            cvBean.setCompany("Pantai Digital Sdn. Bhd.");
            cvBean.setDuration("Mar 2026 - Aug 2026");
            cvBean.setResponsibilities("Built and tested web pages using HTML, JSP and Servlets;"
                    + "Helped fix bugs reported by the quality assurance team;"
                    + "Prepared simple documentation for the internal booking system;"
                    + "Attended weekly meetings and presented progress to the supervisor");
            cvBean.setTechnicalSkills("Java, JSP, Servlet, HTML, MySQL, Git");
            cvBean.setSoftSkills("Teamwork, Communication, Time Management, Problem Solving");
            cvBean.setCertifications("Java Programming Fundamentals;Web Development Workshop Participant");
            cvBean.setLanguages("Malay, English");

            request.setAttribute("cvData", cvBean);
            request.setAttribute("isSample", "yes");
            forwardTo("cvView.jsp", request, response);
        } else {
            // No action: go to the input form
            forwardTo("cvForm.jsp", request, response);
        }
    }

    // POST request: process the form submitted by the user
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // Read the form data
        String fullName = request.getParameter("fullName");
        String professionalTitle = request.getParameter("professionalTitle");
        String email = request.getParameter("email");
        String phone = request.getParameter("phone");
        String profileUrl = request.getParameter("profileUrl");
        String profileSummary = request.getParameter("profileSummary");
        String degree = request.getParameter("degree");
        String major = request.getParameter("major");
        String institution = request.getParameter("institution");
        String graduationYear = request.getParameter("graduationYear");
        String jobTitle = request.getParameter("jobTitle");
        String company = request.getParameter("company");
        String duration = request.getParameter("duration");
        String responsibilities = request.getParameter("responsibilities");
        String technicalSkills = request.getParameter("technicalSkills");
        String softSkills = request.getParameter("softSkills");
        String certifications = request.getParameter("certifications");
        String languages = request.getParameter("languages");

        // Create the bean and set the values
        CVBean cvBean = new CVBean();
        cvBean.setFullName(fullName);
        cvBean.setProfessionalTitle(professionalTitle);
        cvBean.setEmail(email);
        cvBean.setPhone(phone);
        cvBean.setProfileUrl(profileUrl);
        cvBean.setProfileSummary(profileSummary);
        cvBean.setDegree(degree);
        cvBean.setMajor(major);
        cvBean.setInstitution(institution);
        cvBean.setGraduationYear(graduationYear);
        cvBean.setJobTitle(jobTitle);
        cvBean.setCompany(company);
        cvBean.setDuration(duration);
        cvBean.setResponsibilities(responsibilities);
        cvBean.setTechnicalSkills(technicalSkills);
        cvBean.setSoftSkills(softSkills);
        cvBean.setCertifications(certifications);
        cvBean.setLanguages(languages);

        // Validate using the bean
        if (cvBean.validate()) {
            request.setAttribute("cvData", cvBean);
            forwardTo("cvView.jsp", request, response);
        } else {
            request.setAttribute("errors", cvBean.getErrors());
            forwardTo("cvError.jsp", request, response);
        }
    }
    // Forward the request and response to a JSP page
    private void forwardTo(String page, HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        RequestDispatcher dispatcher = request.getRequestDispatcher(page);
        dispatcher.forward(request, response);
    }
}

