package com.cvbuilder.model;

import java.util.ArrayList;
import java.util.List;

public class CVBean {

    // Personal info
    private String fullName;
    private String professionalTitle;
    private String email;
    private String phone;
    private String profileUrl;
    private String profileSummary;

    // Education
    private String degree;
    private String institution;
    private String graduationYear;
    private String major;

    // Experience
    private String jobTitle;
    private String company;
    private String duration;
    private String responsibilities;

    // Skills
    private String technicalSkills;
    private String softSkills;

    // Optional
    private String certifications;
    private String languages;

    // Validation messages
    private ArrayList<String> errors = new ArrayList<String>();

    // Zero-argument constructor
    public CVBean() {
    }

    // Check that the mandatory fields are not empty or malformed
    public boolean validate() {
        errors.clear();

        if (isEmpty(fullName)) {
            errors.add("Full Name is required.");
        }

        if (isEmpty(email)) {
            errors.add("Email is required.");
        } else if (!email.contains("@") || !email.contains(".")) {
            errors.add("Email format is invalid (example: name@example.com).");
        }

        if (isEmpty(degree)) {
            errors.add("Highest Degree is required.");
        }

        if (isEmpty(technicalSkills) && isEmpty(softSkills)) {
            errors.add("At least one skill is required.");
        }

        return errors.isEmpty();
    }

    private boolean isEmpty(String value) {
        return value == null || value.trim().length() == 0;
    }

    // Getters and setters
    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getProfessionalTitle() {
        return professionalTitle;
    }

    public void setProfessionalTitle(String professionalTitle) {
        this.professionalTitle = professionalTitle;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getProfileUrl() {
        return profileUrl;
    }

    public void setProfileUrl(String profileUrl) {
        this.profileUrl = profileUrl;
    }

    public String getProfileSummary() {
        return profileSummary;
    }

    public void setProfileSummary(String profileSummary) {
        this.profileSummary = profileSummary;
    }

    public String getDegree() {
        return degree;
    }

    public void setDegree(String degree) {
        this.degree = degree;
    }

    public String getInstitution() {
        return institution;
    }

    public void setInstitution(String institution) {
        this.institution = institution;
    }

    public String getGraduationYear() {
        return graduationYear;
    }

    public void setGraduationYear(String graduationYear) {
        this.graduationYear = graduationYear;
    }

    public String getMajor() {
        return major;
    }

    public void setMajor(String major) {
        this.major = major;
    }

    public String getJobTitle() {
        return jobTitle;
    }

    public void setJobTitle(String jobTitle) {
        this.jobTitle = jobTitle;
    }

    public String getCompany() {
        return company;
    }

    public void setCompany(String company) {
        this.company = company;
    }

    public String getDuration() {
        return duration;
    }

    public void setDuration(String duration) {
        this.duration = duration;
    }

    public String getResponsibilities() {
        return responsibilities;
    }

    public void setResponsibilities(String responsibilities) {
        this.responsibilities = responsibilities;
    }

    public String getTechnicalSkills() {
        return technicalSkills;
    }

    public void setTechnicalSkills(String technicalSkills) {
        this.technicalSkills = technicalSkills;
    }

    public String getSoftSkills() {
        return softSkills;
    }

    public void setSoftSkills(String softSkills) {
        this.softSkills = softSkills;
    }

    public String getCertifications() {
        return certifications;
    }

    public void setCertifications(String certifications) {
        this.certifications = certifications;
    }

    public String getLanguages() {
        return languages;
    }

    public void setLanguages(String languages) {
        this.languages = languages;
    }

    public List<String> getErrors() {
        return errors;
    }
}

