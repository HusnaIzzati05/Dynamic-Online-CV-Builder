<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Error - CV Builder</title>
    <!-- Tailwind CSS (CDN) -->
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<div class="max-w-2xl mx-auto p-6">

    <h1 class="text-3xl font-bold text-slate-800 mb-4">Dynamic Online CV Builder</h1>

    <div class="bg-white border border-red-600 p-4 mb-4">
        <h2 class="text-xl font-bold text-red-700 mb-2">Your CV could not be generated</h2>
        <p class="mb-2">Please correct the following:</p>
        <ul class="list-disc list-inside">
            <c:forEach var="err" items="${errors}">
                <li><c:out value="${err}"/></li>
            </c:forEach>
        </ul>
    </div>

    <!-- Link back to the form -->
    <a href="cvForm.jsp" class="bg-slate-800 text-white px-4 py-2 inline-block">Back to Form</a>

</div>

</body>
</html>
