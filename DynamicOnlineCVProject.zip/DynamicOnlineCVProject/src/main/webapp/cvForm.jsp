
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Dynamic Online CV Builder</title>

    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>

    <!-- Custom CSS -->
    <link rel="stylesheet" href="css/style.css">
</head>

<body>

<div class="max-w-2xl mx-auto p-6">

    <h1 class="text-3xl font-bold text-slate-800 mb-2">
        Dynamic Online CV Builder
    </h1>

    <p class="text-gray-700 mb-4">
        Fill in your details to generate your CV.
        Fields marked * are required.
    </p>

    <!-- GET flow: Preview Sample CV -->
    <div class="bg-white border p-4 mb-4">
        <p class="mb-2">Want to see an example first?</p>

        <a href="CVServlet?action=sample"
           class="bg-slate-600 text-white px-4 py-2 inline-block">
            Preview Sample CV
        </a>
    </div>

    <!-- POST flow: CV Form -->
    <form action="CVServlet" method="post">

        <!-- PERSONAL INFORMATION -->
        <fieldset class="form-section mb-4">

            <div class="form-heading">
                Personal Information
            </div>

            <label for="fullName" class="block">
                Full Name *
            </label>

            <input type="text" id="fullName" name="fullName"
                   class="border w-full p-1 mb-2" required>

            <label for="professionalTitle" class="block">
                Professional Title
            </label>

            <input type="text" id="professionalTitle"
                   name="professionalTitle"
                   class="border w-full p-1 mb-2">

            <label for="email" class="block">
                Email *
            </label>

            <input type="email" id="email" name="email"
                   class="border w-full p-1 mb-2" required>

            <label for="phone" class="block">
                Phone Number
            </label>

            <input type="text" id="phone" name="phone"
                   class="border w-full p-1 mb-2">

            <label for="profileUrl" class="block">
                LinkedIn / GitHub URL
            </label>

            <input type="text" id="profileUrl" name="profileUrl"
                   class="border w-full p-1 mb-2">

            <label for="profileSummary" class="block">
                Profile Summary
            </label>

            <textarea id="profileSummary" name="profileSummary"
                      rows="4" class="border w-full p-1"></textarea>

        </fieldset>


        <!-- EDUCATION -->
        <fieldset class="form-section mb-4">

            <div class="form-heading">
                Education
            </div>

            <label for="degree" class="block">
                Highest Degree *
            </label>

            <input type="text" id="degree" name="degree"
                   class="border w-full p-1 mb-2" required>

            <label for="major" class="block">
                Major / Field
            </label>

            <input type="text" id="major" name="major"
                   class="border w-full p-1 mb-2">

            <label for="institution" class="block">
                Institution Name
            </label>

            <input type="text" id="institution" name="institution"
                   class="border w-full p-1 mb-2">

            <label for="graduationYear" class="block">
                Year of Graduation
            </label>

            <input type="text" id="graduationYear"
                   name="graduationYear"
                   class="border w-full p-1">

        </fieldset>


        <!-- EXPERIENCE -->
        <fieldset class="form-section mb-4">

            <div class="form-heading">
                Experience
            </div>

            <label for="jobTitle" class="block">
                Most Recent Job Title
            </label>

            <input type="text" id="jobTitle" name="jobTitle"
                   class="border w-full p-1 mb-2">

            <label for="company" class="block">
                Company Name
            </label>

            <input type="text" id="company" name="company"
                   class="border w-full p-1 mb-2">

            <label for="duration" class="block">
                Duration
            </label>

            <input type="text" id="duration" name="duration"
                   class="border w-full p-1 mb-2">

            <label for="responsibilities" class="block">
                Key Responsibilities / Achievements
                (separate with a semicolon ;)
            </label>

            <textarea id="responsibilities" name="responsibilities"
                      rows="4" class="border w-full p-1"></textarea>

        </fieldset>


        <!-- SKILLS AND OTHERS -->
        <fieldset class="form-section mb-4">

            <div class="form-heading">
                Skills and Others
            </div>

            <label for="technicalSkills" class="block">
                Technical Skills * (separate with a comma)
            </label>

            <input type="text" id="technicalSkills"
                   name="technicalSkills"
                   class="border w-full p-1 mb-2" required>

            <label for="softSkills" class="block">
                Soft Skills (separate with a comma)
            </label>

            <input type="text" id="softSkills" name="softSkills"
                   class="border w-full p-1 mb-2">

            <label for="certifications" class="block">
                Certifications (separate with a semicolon ;)
            </label>

            <input type="text" id="certifications"
                   name="certifications"
                   class="border w-full p-1 mb-2">

            <label for="languages" class="block">
                Languages (separate with a comma)
            </label>

            <input type="text" id="languages" name="languages"
                   class="border w-full p-1">

        </fieldset>


        <!-- FORM BUTTONS -->
        <div class="flex gap-2">

            <input type="submit" value="Generate My CV"
                   class="bg-slate-800 text-white px-4 py-2">

            <input type="reset" value="Clear Form"
                   class="bg-gray-300 px-4 py-2">

        </div>

    </form>

</div>

</body>
</html>
