<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>CV - <c:out value="${cvData.fullName}"/></title>
    <!-- Tailwind CSS (CDN) -->
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<div class="max-w-4xl mx-auto p-4">

    <!-- Message and link (not printed) -->
    <div class="no-print mb-4">
        <c:if test="${isSample == 'yes'}">
            <p class="bg-yellow-100 p-2 mb-2">This is a sample CV generated with dummy data.</p>
        </c:if>
        <a href="cvForm.jsp" class="bg-slate-800 text-white px-4 py-2 inline-block">Back to Form</a>
        <span class="text-sm text-gray-700 ml-2">Press Ctrl + P to print or save as PDF.</span>
    </div>

    <!-- CV sheet -->
    <div class="bg-white">

        <!-- Header: name and title -->
        <div class="bg-slate-800 text-white p-6">
            <h1 class="text-4xl font-bold uppercase"><c:out value="${cvData.fullName}"/></h1>
            <p class="text-lg tracking-wide uppercase"><c:out value="${cvData.professionalTitle}"/></p>
        </div>

        <!-- Contact bar -->
        <div class="bg-slate-600 text-white text-sm p-3 flex justify-around">
            <span><c:out value="${cvData.phone}"/></span>
            <span><c:out value="${cvData.email}"/></span>
            <span><c:out value="${cvData.profileUrl}"/></span>
        </div>

        <!-- Body: sidebar and main column -->
        <div class="flex">

            <!-- Left sidebar -->
            <div class="w-1/3 bg-slate-800 text-white p-6">

                <h2 class="text-lg font-bold uppercase border-b pb-1 mb-2">Education</h2>
                <p class="font-bold"><c:out value="${cvData.degree}"/></p>
                <p class="text-sm"><c:out value="${cvData.major}"/></p>
                <p class="text-sm"><c:out value="${cvData.institution}"/></p>
                <p class="text-sm mb-6"><c:out value="${cvData.graduationYear}"/></p>

                <c:if test="${not empty cvData.certifications}">
                    <h2 class="text-lg font-bold uppercase border-b pb-1 mb-2">Certifications</h2>
                    <ul class="list-disc list-inside text-sm mb-6">
                        <c:forTokens items="${cvData.certifications}" delims=";" var="cert">
                            <li><c:out value="${cert}"/></li>
                        </c:forTokens>
                    </ul>
                </c:if>

                <c:if test="${not empty cvData.technicalSkills}">
                    <h2 class="text-lg font-bold uppercase border-b pb-1 mb-2">Technical Skills</h2>
                    <ul class="skill-pills text-sm mb-6">
                        <c:forTokens items="${cvData.technicalSkills}" delims="," var="skill">
                            <li><c:out value="${skill}"/></li>
                        </c:forTokens>
                    </ul>
                </c:if>

                <c:if test="${not empty cvData.softSkills}">
                    <h2 class="text-lg font-bold uppercase border-b pb-1 mb-2">Soft Skills</h2>
                    <ul class="text-sm mb-6">
                        <c:forTokens items="${cvData.softSkills}" delims="," var="skill">
                            <li><c:out value="${skill}"/></li>
                        </c:forTokens>
                    </ul>
                </c:if>

                <c:if test="${not empty cvData.languages}">
                    <h2 class="text-lg font-bold uppercase border-b pb-1 mb-2">Languages</h2>
                    <ul class="skill-pills text-sm">
                        <c:forTokens items="${cvData.languages}" delims="," var="lang">
                            <li><c:out value="${lang}"/></li>
                        </c:forTokens>
                    </ul>
                </c:if>

            </div>

            <!-- Right main column -->
            <div class="w-2/3 p-6 text-gray-700">

                <c:if test="${not empty cvData.profileSummary}">
                    <h2 class="text-xl font-bold text-slate-800 uppercase border-b border-slate-800 pb-1 mb-2">About Me</h2>
                    <p class="text-sm mb-6"><c:out value="${cvData.profileSummary}"/></p>
                </c:if>

                <c:if test="${not empty cvData.jobTitle}">
                    <h2 class="text-xl font-bold text-slate-800 uppercase border-b border-slate-800 pb-1 mb-2">Experience</h2>
                    <div class="flex justify-between">
                        <p class="font-bold text-black"><c:out value="${cvData.jobTitle}"/></p>
                        <p class="text-sm"><c:out value="${cvData.duration}"/></p>
                    </div>
                    <p class="text-sm mb-2"><c:out value="${cvData.company}"/></p>
                    <ul class="list-disc list-inside text-sm">
                        <c:forTokens items="${cvData.responsibilities}" delims=";" var="item">
                            <li><c:out value="${item}"/></li>
                        </c:forTokens>
                    </ul>
                </c:if>

            </div>

        </div>

    </div>

</div>

</body>
</html>
